class UserDao {

    constructor(pool) {
        this._pool = pool;
    }

    userLogin(email) {
        const cmd = "select * from users where email = '" + email + "'";
        return new Promise((resolve, reject) => {
            this._pool
            .query(cmd, (error, result) => {
                if (error) {
                    return reject(error);
                }
                return resolve(result.rows[0]);
            });
        });
    }

    userCheck(email) {
        const cmd = "select exists (select true from usersout where email = '" + email + "') as email;";
        return new Promise((resolve, reject) => {
            this._pool
            .query(cmd, (error, result) => {
                if (error) {
                    return reject(error);
                }
                return resolve(result.rows[0]);
            });
        });
    }
}    
module.exports = UserDao;